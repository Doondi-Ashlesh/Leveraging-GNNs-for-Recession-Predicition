
#WORKING - Predictions using trained GNN models 
#Our case particularly using TGNN.
"""

 Gradio Interface (TGNN)
---------------------
This script loads a TGNN model (previously trained by us) and its corresponding StandardScaler,
then launches a Gradio app that:

- Accepts a comma-separated string of input features
- Auto-fills feature input boxes
- Runs the model on the normalized input
- Returns the prediction and probabilities

NOTE: The current interface only works with TGNN. If you want to load and test GCN or other models the architecture should be defined in the code and the related files (graph_edges.pt,scaler.pkl,features.pkl,other_model.pth) for the model should be avaialable.

How to run:
-----------
1. Make sure your environment has the required dependencies:
Python 3.12,Gradio 4.36.0,Pydantic 2.5.3,FastAPI 0.109.0,Starlette 0.35.1
!!!Install other ddependencies as per requirement.

pip install torch numpy gradio scikit-learn

2. Place your saved model ('TGNN_SMOTE_focal_40e.pth'), scaler ('scaler_tgnn.pkl'),
   feature list ('feature_list.pkl'), and graph data ('graph_edges.pt')
   in the same directory as this script.

3. Run this script:
   python tgnn_gradio_interface.py
   or
   just open and run the file in a coding environment

4. Open your browser at http://127.0.0.1:7860
"""
#Imports & Libraries
#All are not necessary, just included everything we used to avoid any trouble.

import gradio as gr
import torch
import joblib
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import networkx as nx
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score
from torch_geometric.data import Data
from torch_geometric.loader import DataLoader
from torch_geometric.nn import GCNConv, global_mean_pool




# === Load Model and Scaler ===
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# === TGNN Model === 
class TGNN(nn.Module):
    def __init__(self, in_channels, gcn_hidden, gru_hidden, out_channels=2):
        super().__init__()
        self.conv1 = GCNConv(in_channels, gcn_hidden)
        self.conv2 = GCNConv(gcn_hidden, gcn_hidden)
        self.gru = nn.GRU(gcn_hidden, gru_hidden, batch_first=True)
        self.lin = nn.Linear(gru_hidden, out_channels)

    def forward(self, x_seq, edge_index, edge_weight):
        # x_seq: [T, N, in_channels]
        g_seq = []
        for t in range(x_seq.size(0)):
            h = F.relu(self.conv1(x_seq[t], edge_index, edge_weight))
            h = F.dropout(h, p=0.3, training=self.training)
            h = F.relu(self.conv2(h, edge_index, edge_weight))
            g_seq.append(h.mean(dim=0))  # [hidden]
        g_seq = torch.stack(g_seq, dim=0).unsqueeze(0)  # [1, T, hidden]
        out_seq, _ = self.gru(g_seq)  # [1, T, gru_hidden]
        out_seq = out_seq.squeeze(0)  # [T, gru_hidden]
        return self.lin(out_seq)     # [T, 2]


# Load trained model
tgnn_model = TGNN(in_channels=1, gcn_hidden=64, gru_hidden=64).to(device)
tgnn_model.load_state_dict(torch.load("TGNN_SMOTE_focal_40e.pth", map_location=device))#Load takes the saved model.
tgnn_model.eval()

# Load scaler
scaler = joblib.load("scaler_tgnn.pkl")

# Load feature list
features_list = joblib.load("feature_list.pkl")
num_features = len(features_list)

# Load edge_index and edge_weight
edge_data = torch.load("graph_edges.pt")
edge_index = edge_data["edge_index"]
edge_weight = edge_data["edge_weight"]

# === Step 1: CSV to Field Values ===
def parse_csv_input(input_string):
    try:
        values = [float(x.strip()) for x in input_string.split(",")]
        if len(values) != num_features:
            raise ValueError(f"Expected {num_features} values, got {len(values)}")
        return tuple(values)
    except Exception as e:
        return tuple([None] * num_features)

# === Step 2: Predict ===
def predict_recession(*features):
    raw_input = np.array(features, dtype=np.float32).reshape(1, -1)
    normalized_input = scaler.transform(raw_input)
    input_tensor = torch.tensor(normalized_input.reshape(1, -1, 1), dtype=torch.float32).to(device)

    with torch.no_grad():
        output = tgnn_model(input_tensor, edge_index.to(device), edge_weight.to(device))
        probs = torch.softmax(output[-1], dim=0).cpu().numpy()
        pred_class = int(np.argmax(probs))

    return (
        "Recession" if pred_class == 1 else "No Recession",
        round(probs[1], 4),
        round(probs[0], 4)
    )

# === Interface ===
with gr.Blocks() as demo:
    gr.Markdown("### Recession Prediction using TGNN ")

    with gr.Row():
        csv_input = gr.Textbox(label="Comma-separated feature values", placeholder="e.g., 2.3, 4000, 0.9, ...")
        parse_btn = gr.Button("Auto-fill")

    form_inputs = [gr.Number(label=feat) for feat in features_list]

    with gr.Row():
        predict_btn = gr.Button("Predict")

    prediction = gr.Textbox(label="Prediction")
    prob_recession = gr.Textbox(label="Probability (Recession)")
    prob_no_recession = gr.Textbox(label="Probability (No Recession)")

    parse_btn.click(fn=parse_csv_input, inputs=[csv_input], outputs=form_inputs)
    predict_btn.click(fn=predict_recession, inputs=form_inputs, outputs=[prediction, prob_recession, prob_no_recession])

demo.launch()


#GOOD TO GO!!!
